# Change Logs

## [2.0.0] 2022-08-19

- Update the dependencies
- Add new components
- Add new built-in examples
- Add new layouts
- Change the base structure for entire project
- Fix the issues

## [1.2.2] 2019-12-13

### Dependencies Updates

- Updated all out of date dependencies from `package.json` file
- The version is now `v1.2.2` to have the same versioning line with the PRO version of this product

## [1.2.0] 2019-07-19

### Updates

- Vue Material updated to the latest release `v1.0.0-beta-11`
- Vuejs updated to the latest release `v2.6.10`
- Updated the rest of dependencies to the latest release

## [1.1.0] 2019-01-22

### Updates

- Updated all dependencies to the last version

## [1.0.1] 2019-01-22

### Feature

- button `Vue Material Kit Pro` from `index.vue` activated

## [1.0.0] 2018-09-27

### Initial Release
