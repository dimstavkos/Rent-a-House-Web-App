<script setup>
//Vue Material Kit 2 components
import MaterialSwitch from "@/components/MaterialSwitch.vue";
</script>
<template>
  <div class="container py-6 mt-3">
    <div class="row flex justify-content-center">
      <div class="col-4 ms-10">
        <MaterialSwitch
          class="d-flex align-items-center ps-6"
          id="flexSwitchCheckDefault"
          labelClass="ms-3 mb-0"
        >
          Remember me
        </MaterialSwitch>
      </div>
    </div>
  </div>
</template>
