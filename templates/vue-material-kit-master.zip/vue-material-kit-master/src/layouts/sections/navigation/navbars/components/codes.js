export const navbarDarkCode = `<script setup>
// example component
import NavbarDefault from "@/examples/navbars/NavbarDefault.vue";
</script>
<template>
  <NavbarDefault dark transparent />
</template>
`;
